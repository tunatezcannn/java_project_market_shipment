package Production;

public class Item {
	private String itemCode, serialNumber, itemName;
	private double volume; 
	private int cost, price;
	
	public Item(String itemCode, double volume, String serialNumber, int cost, int price, String itemName) {
		this.itemCode = itemCode;
		this.volume = volume;
		this.serialNumber = serialNumber;
		this.cost = cost;
		this.price = price;
		this.itemName = itemName;
	}
	
	public String getItemCode() {
		return itemCode;
	}

	public double getVolume() {
		return volume;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public int getCost() {
		return cost;
	}

	public int getPrice() {
		return price;
	}

	public String getItemName() {
		return itemName;
	}
	
	
}
