package Production;

public class CountableBox<T> extends Box<T> {
	private int numberOfItems;

	public CountableBox(String boxCode, int numberOfItems, double volume, String boxSerialNumber, int cost, String boxName) {
		super(boxCode, volume, boxSerialNumber, cost, boxName);
		this.numberOfItems = numberOfItems;
		System.out.println(toString());
	}

	public int getNumberOfItems() {
		return numberOfItems;
	}
	
	@Override
	public String toString() {
		return getVolume() + " liter(s) of " + getBoxName() + " has been produced with capacity of " + getNumberOfItems() + " with the serial number " + getBoxSerialNumber();
	}
	@Override
	public boolean checkCapacity(T item2) {
		double totalNumber = 1;
		double totalVolume = ((Item)item2).getVolume();
		for(Object item: super.getItems()) {
			totalNumber+=1;
			totalVolume+=((Item)item).getVolume();
		}
		if(totalNumber<=numberOfItems && totalVolume <= super.getVolume()) {
			return true;
		}
		else { 
			return false;	
		}
	}
}
