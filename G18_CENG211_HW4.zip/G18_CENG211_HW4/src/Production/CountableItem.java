package Production;

public class CountableItem extends Item{

	public CountableItem(String itemCode, double volume, String serialNumber, int cost, int price, String itemName) {
		super(itemCode, volume, serialNumber, cost, price, itemName);
		System.out.println(toString());
	}

	@Override
	public String toString() {
		return getVolume() + " liter(s) of " + getItemName() + " has been produced with the serial number " + getSerialNumber();
	}
}
