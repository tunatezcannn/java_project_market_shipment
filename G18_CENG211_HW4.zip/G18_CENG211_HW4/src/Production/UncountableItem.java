package Production;

public class UncountableItem extends Item{
	private double mass;

	public UncountableItem(String itemCode, double mass, double volume, String serialNumber, int cost, int price, String itemName) {
		super(itemCode, volume, serialNumber, cost, price, itemName);
		this.mass = mass;
		System.out.println(toString());
	}

	public double getMass() {
		return mass;
	}

	@Override
	public String toString() {
		return getMass() + " kilogram(s) of " + getItemName() + " has been produced with the serial number " + getSerialNumber();
	}

}
