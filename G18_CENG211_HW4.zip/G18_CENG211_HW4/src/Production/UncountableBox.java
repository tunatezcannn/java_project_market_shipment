package Production;

public class UncountableBox<T> extends Box<T> {
	private double mass;

	public UncountableBox(String boxCode, double mass, double volume, String boxSerialNumber, int cost, String boxName) {
		super(boxCode, volume, boxSerialNumber, cost, boxName);
		this.mass = mass;
		System.out.println(toString());
	}

	public double getMass() {
		return mass;
	}

	@Override
	public String toString() {
		return getVolume() + " liter(s) of " + getBoxName() + " has been produced with capacity of " + getMass() + " kg with the serial number " + getBoxSerialNumber();
	}
	@Override
	public boolean checkCapacity(T item2) {
		double totalMass = ((UncountableItem)item2).getMass();
		double totalVolume = ((Item)item2).getVolume();
		for(Object item: super.getItems()) {
			totalMass+=((UncountableItem)item).getMass();
			totalVolume+=((Item)item).getVolume();
		}
		if(totalMass<=mass && totalVolume <= super.getVolume()) {
			return true;
		}
		else { 
			return false;	
		}
	}
}
