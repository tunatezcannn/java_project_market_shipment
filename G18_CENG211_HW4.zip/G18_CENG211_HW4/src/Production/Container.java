package Production;

import java.util.ArrayList;
import java.util.List;

public class Container {
	private String containerCode, containerSerialNumber, name;
	private double volume;
	private int cost;	
	private List<Box<Item>> boxes = new ArrayList<Box<Item>>();
	
	public Container(String containerCode, double volume, String containerSerialNumber, int cost, String name) {
		this.containerCode = containerCode;
		this.volume = volume;
		this.containerSerialNumber = containerSerialNumber;
		this.cost = cost;
		this.name = name;
		System.out.println(toString());
	}

	public String getContainerCode() {
		return containerCode;
	}

	public double getVolume() {
		return volume;
	}

	public String getContainerSerialNumber() {
		return containerSerialNumber;
	}

	public int getCost() {
		return cost;
	}
	
	public String getName() {
		return name;
	}

	public List<Box<Item>> getBoxes() {
		return boxes;
	}

	@Override
	public String toString() {
		return getVolume() + " liter(s) of " + getName() + " has been produced with the serial number " + getContainerSerialNumber();
	}
}
