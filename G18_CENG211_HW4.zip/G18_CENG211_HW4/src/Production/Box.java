package Production;

import java.util.*;

@SuppressWarnings("rawtypes")
public class Box<T> implements Collection {
	private String boxCode, boxSerialNumber, boxName;
	private double volume;
	private int cost;
	private List<T> items = new ArrayList<T>();
	
	public Box(String boxCode, double volume, String boxSerialNumber, int cost, String boxName) {
		this.boxCode = boxCode;
		this.boxSerialNumber = boxSerialNumber;
		this.boxName = boxName;
		this.volume = volume;
		this.cost = cost;
	}
	
	public boolean checkCapacity(T item) {
		return false;
	}

	@Override
	public int size() {
		return items.size();
	}

	@Override
	public boolean isEmpty() {
		if(this.size()==0) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public boolean contains(Object o) {
		if(items.contains(o)) {
			return true;
		}
		else return false;
	}

	@Override
	public Iterator iterator() {
		return null;
	}

	@Override
	public Object[] toArray() {
		return items.toArray();
	}

	@Override
	public Object[] toArray(Object[] a) {
		return items.toArray();
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean add(Object e) {
		items.add((T) e);
		return true;
	}

	@Override
	public boolean remove(Object o) {
		if(this.size()>0) {
			items.remove(o);
			return true;
		}
		else {
			return false;
		}
		
	}

	@Override
	public boolean containsAll(Collection c) {
		if(items.containsAll(c)) {
			return true;
		}
		else return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean addAll(Collection c) {
		items.addAll(c);
		return true;
	}

	@Override
	public boolean removeAll(Collection c) {
		items.removeAll(c);
		return true;
	}

	@Override
	public boolean retainAll(Collection c) {
		items.retainAll(c);
		return true;
	}

	@Override
	public void clear() {
		items.clear();
	}
	
	public String getBoxCode() {
		return boxCode;
	}

	public String getBoxSerialNumber() {
		return boxSerialNumber;
	}

	public String getBoxName() {
		return boxName;
	}

	public double getVolume() {
		return volume;
	}

	public int getCost() {
		return cost;
	}

	public List<T> getItems() {
		return items;
	}
}
