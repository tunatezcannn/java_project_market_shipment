package Exception;

@SuppressWarnings("serial")
public class ExistingSerialNumberException extends Exception{

	public ExistingSerialNumberException() {
		super("Exception Code: 1 Existing Serial Number" );
	}

}
