package Exception;

@SuppressWarnings("serial")
public class ExceedNumberBoxCapacityException extends Exception {
	public ExceedNumberBoxCapacityException() {
		super("Exception Code: 4 Number Box Capacity Full" );
	}
}
