package Exception;

@SuppressWarnings("serial")
public class ThereIsNoBoxToLoadException extends Exception{
	public ThereIsNoBoxToLoadException() {
		super("Exception Code: 8 There is no box to load" );
	}
}
