package Exception;

@SuppressWarnings("serial")
public class UncountableToCountableException extends Exception {
	public UncountableToCountableException() {
		super("Exception Code: 2 Uncountable Item To Countable Box" );
	}
}
