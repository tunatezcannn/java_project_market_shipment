package Exception;

@SuppressWarnings("serial")
public class CannotPlaceToContainerException extends Exception {
	public CannotPlaceToContainerException() {
		super("Exception Code: 7 Cannot Place To Container" );
	}
}
