package Exception;

@SuppressWarnings("serial")
public class CountableToUncountableException extends Exception{
	public CountableToUncountableException() {
		super("Exception Code: 3 Countable Item To Uncountable Box" );
	}
}
