package Exception;

@SuppressWarnings("serial")
public class ExceedMassBoxCapacityException extends Exception  {
	public ExceedMassBoxCapacityException() {
		super("Exception Code: 5 Mass Box Capacity Full" );
	}
}
