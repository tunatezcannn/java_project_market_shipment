package FileIO;

import java.io.*;
import java.util.*;
import Exception.*;
import Production.*;

public class FileIO {
	
	List<Item> countableItems = new ArrayList<Item>();
	List<Item> uncountableItems = new ArrayList<Item>();
	
	List<Container> containers = new ArrayList<Container>();
	
	List<Box<Item>> countableBoxes = new ArrayList<Box<Item>>();
	List<Box<Item>> uncountableBoxes = new ArrayList<Box<Item>>();
	
	public void readCommands() throws IOException, Exception{
		BufferedReader reader = new BufferedReader(new FileReader("ExampleCommands.csv"));
		
		String line;
		
		while((line = reader.readLine()).startsWith("1") || line.startsWith("2") || line.startsWith("3") || line.startsWith("4")) {
			switch (line.split(",")[0]) {
			case "1": {
				//produce
				if (line.split(",")[1].startsWith("B1")) {
					produceCountableBox(line);
				}
				else if (line.split(",")[1].startsWith("B2")) {
					produceUncountableBox(line);						
				}
				else if (line.split(",")[1].startsWith("C")) {
					produceContainer(line);
				}
				else if (line.split(",")[1].startsWith("M") || line.split(",")[1].startsWith("W") || line.split(",")[1].startsWith("O")) {
					produceCountableItem(line);
				}
				else if (line.split(",")[1].startsWith("S") || line.split(",")[1].startsWith("F") || line.split(",")[1].startsWith("P") || line.split(",")[1].startsWith("R")) {
					produceUncountableItem(line);					
				}
				else {
					throw new IllegalArgumentException("Unexpected value: " + line.split(",")[1]); 
				}
				break;
			}
			case "2": {
				//load
				try {
					if ((line.split(",")[1].startsWith("M") || line.split(",")[1].startsWith("W") || line.split(",")[1].startsWith("O")) && (line.split(",")[2].startsWith("B1"))) {
						countableItemLoad(line);
					}
					else if ((line.split(",")[1].startsWith("M") || line.split(",")[1].startsWith("W") || line.split(",")[1].startsWith("O")) && (line.split(",")[2].startsWith("B2"))) {
						throw new CountableToUncountableException();
					}
					else if ((line.split(",")[1].startsWith("S") || line.split(",")[1].startsWith("F") || line.split(",")[1].startsWith("P") || line.split(",")[1].startsWith("R")) && (line.split(",")[2].startsWith("B2"))) {
						uncountableItemLoad(line);					
					}
					else if ((line.split(",")[1].startsWith("S") || line.split(",")[1].startsWith("F") || line.split(",")[1].startsWith("P") || line.split(",")[1].startsWith("R")) && (line.split(",")[2].startsWith("B1"))) {
						throw new UncountableToCountableException();					
					}
					else if (line.split(",")[1].startsWith("B") && (line.split(",")[2].startsWith("C"))) {
						//
					}
					else if (!line.split(",")[1].startsWith("B") && (line.split(",")[2].startsWith("C"))) {
						throw new CannotPlaceToContainerException();
					}
					else {
						throw new Exception();
					}
				}
				catch(CountableToUncountableException e) {
					System.out.println("Item with the serial number " + line.split(",")[1] + " cannot be placed to the box " + line.split(",")[2] + " (" + e.getMessage() + ")");

				}
				catch(UncountableToCountableException e) {
					System.out.println("Item with the serial number " + line.split(",")[1] + " cannot be placed to the box " + line.split(",")[2] + " (" + e.getMessage() + ")");

				}
				catch(CannotPlaceToContainerException e) {
					System.out.println("Object with the serial number " + line.split(",")[1] + " cannot be placed to the container " + line.split(",")[2] + " (" + e.getMessage() + ")");

				}
				catch(Exception e) {
					System.out.println(e.getMessage());
				}
				
				break;
			}
			case "3": {
				//ship
				break;
			}
			case "4": {
				//show
				break;
			}
			default:
				throw new IllegalArgumentException("Unexpected value: " + line.split(",")[0]);
			}
		}
		reader.close();
	}

	private void uncountableItemLoad(String line) {
		try {
			for(Item item: uncountableItems) {
				if(item.getSerialNumber().equals(line.split(",")[1])) {
					for(Box<Item> box: uncountableBoxes) {
						if(box.getBoxSerialNumber().equals(line.split(",")[2])) {
							if(box.checkCapacity(item)) {
								box.add(item);
								break;
							}
							else {
								throw new ExceedMassBoxCapacityException();
							}
						}	
					}
				}
			}
		}
		catch(ExceedMassBoxCapacityException e) {
			System.out.println("Item with the serial number " + line.split(",")[1] + " cannot be placed to the box " + line.split(",")[2] + " (" + e.getMessage() + ")");
		}
//		catch(ThereIsNoBoxToLoadException e) {
//			System.out.println("Item with the serial number " + line.split(",")[1] + " cannot be placed to the box " + line.split(",")[2] + " (" + e.getMessage() + ")");
//		}
		
	}

	private void countableItemLoad(String line){
		try {
			for(Item item: countableItems) {
				if(item.getSerialNumber().equals(line.split(",")[1])) {
					for(Box<Item> box: countableBoxes) {
						if(box.getBoxSerialNumber().equals(line.split(",")[2])) {
							if(box.checkCapacity(item)) {
								box.add(item);
								break;
							}
							else {
								throw new ExceedNumberBoxCapacityException();
							}
						}
					}
				}
			}
		}
		catch(ExceedNumberBoxCapacityException e) {
			System.out.println("Item with the serial number " + line.split(",")[1] + " cannot be placed to the box " + line.split(",")[2] + " (" + e.getMessage() + ")");
		}
	}

	private void produceUncountableItem(String line) throws Exception{
		try {
			int cost = 0, price = 0;
			String itemName = null; 
			String itemCode = line.split(",")[1];
			if (itemCode.startsWith("S")) {
				cost = 13;
				price = 25;
				itemName = "sugar";
			}
			else if (itemCode.startsWith("F")) {
				cost = 5;
				price = 12;
				itemName = "flour";
			}
			else if (itemCode.startsWith("P")) {
				cost = 12;
				price = 28;
				itemName = "pasta";
			}
			else if (itemCode.startsWith("R")) {
				cost = 16;
				price = 32;
				itemName = "rice";
			}
			double mass = Double.parseDouble(line.split(",")[2]);
			double volume = Double.parseDouble(line.split(",")[3]);
			String serialNumber = line.split(",")[4];
			
			
			if (doesItemExist(serialNumber, uncountableItems)) {
				throw new ExistingSerialNumberException();
			}
			else {
				Item newItem = new UncountableItem(itemCode, mass, volume, serialNumber, cost, price, itemName);
				uncountableItems.add(newItem);					
			}	
		}
		catch(ExistingSerialNumberException e) {
			System.out.println("Item with the serial number " + line.split(",")[4] + " cannot be produced (" + e.getMessage() + ")");
		}
	}


	private void produceCountableItem(String line) {
		try {
			int cost = 0, price = 0;
			String itemName = null;
			String itemCode = line.split(",")[1];
			if (itemCode.startsWith("M")) {
				cost = 5;
				price = 11;
				itemName = "box of milk";
			}
			else if (itemCode.startsWith("W")) {
				cost = 1;
				price = 3;
				itemName = "box of water";
			}
			else if (itemCode.startsWith("O")) {
				cost = 20;
				price = 45;
				itemName = "box of oil";
			}
			
			double volume = Double.parseDouble(line.split(",")[2]);
			String serialNumber = line.split(",")[3];
			
			if (doesItemExist(serialNumber, countableItems)) {
				throw new ExistingSerialNumberException();
			}
			else {
				Item newItem = new CountableItem(itemCode, volume, serialNumber, cost, price, itemName);
				countableItems.add(newItem);				
			}
		}
		catch (ExistingSerialNumberException e){
			System.out.println("Item with the serial number " + line.split(",")[3] + " cannot be produced (" + e.getMessage() + ")");
		}
	}

	private void produceContainer(String line) {
		try {
			String name = "container";
			String containerCode = line.split(",")[1];
			double volume = Integer.parseInt(line.split(",")[2]);
			String containerSerialNumber = line.split(",")[3];
			
			if (doesContainerExist(containerSerialNumber, containers)) {
				throw new ExistingSerialNumberException();
			}
			else {
				Container newContainer = new Container(containerCode, volume, containerSerialNumber, 1, name);
				containers.add(newContainer);				
			}
		}
		catch (ExistingSerialNumberException e) {
			System.out.println("Container with the serial number " + line.split(",")[3] + " cannot be produced (" + e.getMessage() + ")");
		}
	}

	private void produceUncountableBox(String line) {
		try {
			String name = "mass box";
			String boxCode = line.split(",")[1];
			double mass = Double.parseDouble(line.split(",")[2]);
			double volume = Double.parseDouble(line.split(",")[3]);
			String boxSerialNumber = line.split(",")[4];
			
			if (doesBoxExist(boxSerialNumber, uncountableBoxes)) {
				throw new ExistingSerialNumberException();
			}
			else {
				Box<Item> newBox = new UncountableBox<Item>(boxCode, mass, volume, boxSerialNumber, 3, name);
				uncountableBoxes.add(newBox);			
			}
		}
		catch (ExistingSerialNumberException e) {
			System.out.println("Box with the serial number " + line.split(",")[4] + " cannot be produced (" + e.getMessage() + ")");
		}
			
	}

	private void produceCountableBox(String line) {
		try {
			String name = "number box";
			String boxCode = line.split(",")[1];
			int numberOfItems = Integer.parseInt(line.split(",")[2]);
			double volume = Double.parseDouble(line.split(",")[3]);
			String boxSerialNumber = line.split(",")[4];
			
			if (doesBoxExist(boxSerialNumber, countableBoxes)) {
				throw new ExistingSerialNumberException();
			}
			else {
				Box<Item> newBox = new CountableBox<Item>(boxCode, numberOfItems, volume, boxSerialNumber, 2, name);
				countableBoxes.add(newBox);		
			}
		}
		catch (ExistingSerialNumberException e) {
			System.out.println("Box with the serial number " + line.split(",")[4] + " cannot be produced (" + e.getMessage() + ")");
		}
	}
	
	
	private boolean doesItemExist(String serialNumber, List<Item> list) {
		for (Item i: list) {
			if(i.getSerialNumber().equals(serialNumber)) {
				return true;
			}
			else {
				continue;
			}
		}
		return false;
	}
	
	private boolean doesBoxExist(String serialNumber, List<Box<Item>> list) {
		for (Box<Item> i: list) {
			if(i.getBoxSerialNumber().equals(serialNumber)) {
				return true;
			}
			else {
				continue;
			}
		}
		return false;
	}
	
	private boolean doesContainerExist(String serialNumber, List<Container> list) {
		for (Container i: list) {
			if(i.getContainerSerialNumber().equals(serialNumber)) {
				return true;
			}
			else {
				continue;
			}
		}
		return false;
	}
	
}
