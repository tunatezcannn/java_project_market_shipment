package MarketShipmentSimulation;


import FileIO.*;

public class MarketShipmentSimulationApp {
	public static void main(String[] args) throws Exception {
		FileIO f = new FileIO();
		f.readCommands();
	}
}
